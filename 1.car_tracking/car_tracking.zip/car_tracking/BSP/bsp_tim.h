/*
 * bsp_tim.h
 *
 *  Created on: 2023年10月18日
 *      Author: YB-101
 */

#ifndef BSP_TIM_BSP_TIM_H_
#define BSP_TIM_BSP_TIM_H_

#include "bsp.h"

void Bsp_Tim_Init(void);

#endif /* BSP_TIM_BSP_TIM_H_ */
